import { prebuiltAppConfig } from "../../../lib/config";

export default {
	"model_list": prebuiltAppConfig.model_list,
	"use_web_worker": true
}
